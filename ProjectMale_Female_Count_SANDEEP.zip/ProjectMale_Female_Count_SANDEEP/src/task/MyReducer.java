package task;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,Text,Text,Text>{
        public void reduce(Text key,Iterable<Text> values,Context context) throws IOException, InterruptedException{
        	int count_male=0;
        	int count_female=0;
        	
        	for(Text value:values){
        		if(value.toString().trim().equals("Male"))
        			count_male++;
        		if(value.toString().trim().equals("Female"))
        			count_female++;	
        	}
        	
        	context.write(key, new Text("Male "+count_male));
        	context.write(key, new Text("Female "+count_female));
        }
}
